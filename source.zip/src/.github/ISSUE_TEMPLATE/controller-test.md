---
name: Controller compatibility report
about: Report a ProCon 0.2 controller test
---
Controller brand / exact model / revision:
VID / PID shown by ProCon:
PS4 model / firmware:
GoldHEN version:
Game / CUSA:
Other enabled plugins:

Result (works / wrong mapping / no input / crash):
Buttons / sticks / triggers tested:
Disconnect and reconnect result:
Last notification or error:
Photo/video:

Did the installer stay open after confirmation until you closed it?
